package com.example.controllers;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.entity.Movie;
import com.example.responses.GenreResponse;
import com.example.responses.MovieResponse;
import com.example.services.MovieService;


@RestController
@RequestMapping("/movies/")
public class MovieController {
	@Autowired
	private RestTemplate restobj;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private MovieService serv;
	
	@Autowired
	private LoadBalancerClient loadbal;
	
	@GetMapping("/{id}")
	public ResponseEntity<MovieResponse> GetById(@PathVariable int id)
	{
		Movie mov=serv.getMovieBasedOnId(id);
		MovieResponse resp=modelMapper.map(mov, MovieResponse.class);
		int genreID = resp.getMovGenreId();
		
		ServiceInstance service= loadbal.choose("GENRE-API");
		String uri=service.getUri().toString();
		String FinalUri=uri+"/movie-genre/api/genres/id?genre_id="+genreID;
		
		GenreResponse genre= restobj.getForObject(FinalUri, GenreResponse.class);
		resp.setGenre(genre);
		
		return ResponseEntity.status(HttpStatus.OK).body(resp);
	}
	
	@GetMapping("/list")
	public ResponseEntity<List<Movie>> GetAll()
	{
		List<Movie> movies=serv.GetAllMovies();
		return ResponseEntity.status(HttpStatus.OK).body(movies);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Movie> Add(@RequestBody Movie mov)
	{
		Movie movie=serv.addMovie(mov);
		return ResponseEntity.status(HttpStatus.CREATED).body(movie);
	}
	
	@PutMapping("/edit")
	public ResponseEntity<Movie> Update(@RequestBody Movie mov)
	{
		Movie movie=serv.updateMovie(mov);
		return ResponseEntity.ok(movie);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> Delete(@PathVariable int id)
	{
		serv.deleteMovie(serv.getMovieBasedOnId(id));
		return ResponseEntity.ok("Deleted Successfully!");
	}
	
	//list movies by genre
	@GetMapping("/listbygenre")
	public ResponseEntity<List<Movie>> GetAllGenreMovies(@RequestParam int genreId)
	{
		System.out.println("MovieService Controller - GetAllGenreMovies() genreId = [" + genreId +"]");
		if (genreId > 0) {
			List<Movie> movies=serv.findByMovGenreId(genreId);
			return ResponseEntity.status(HttpStatus.OK).body(movies);			
		} else {
			List<Movie> movies=serv.GetAllMovies();
			return ResponseEntity.status(HttpStatus.OK).body(movies);					
		}

	}

	//search movies by keyword
    @GetMapping("/keywordsearch")
    public ResponseEntity<List<Movie>> searchMoviesByKeyword(@RequestParam(name = "keyword") String keyword) {
        // Check if a keyword is provided.
        if (keyword != null && !keyword.isEmpty()) {
        	
        	//Retrieve the list of Genre IDs if the keyword matches any of the Movie Genre
    		ServiceInstance service= loadbal.choose("GENRE-API");
    		String uri=service.getUri().toString();
    		String FinalUri=uri+"/movie-genre/api/genres/searchByKeyword?keyword="+keyword;
    		
    		List<Integer> genreIds = restobj.getForObject(FinalUri, List.class);

    		if (genreIds.isEmpty()) {
    			//search all columns EXCEPT genre id
    			List<Movie> movies=serv.searchMoviesByKeyword(keyword);
    			return ResponseEntity.status(HttpStatus.OK).body(movies);   			
    		}else {
    			//search all columns including genre id
    			List<Movie> movies=serv.searchAllColumns(keyword, genreIds);
    			return ResponseEntity.status(HttpStatus.OK).body(movies);
    		}
            
        } else {
            // If no keyword is provided, return all movies.
			List<Movie> movies=serv.GetAllMovies();
			return ResponseEntity.status(HttpStatus.OK).body(movies);
        }
    }

}
