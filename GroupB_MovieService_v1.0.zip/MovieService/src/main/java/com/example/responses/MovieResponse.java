package com.example.responses;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MovieResponse {
	private int mov_id;
	private String movTitle;
	private String movDescription;
	private int movRelYear; 
	private String movLanguage; 
	private int movRuntime;
	private String movDirector;
	private String movCast;
	private double movRating;
	private int movGenreId;
	private GenreResponse genre;
	
}
