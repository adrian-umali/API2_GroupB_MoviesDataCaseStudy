package com.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="movie")
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mov_id;
	
	@Column(name="mov_title", nullable=false)
	private String movTitle;

	@Column(name="mov_description", nullable=false)
	private String movDescription;

	@Column(name="mov_relyear", nullable=false)
	private int movRelYear; 

	@Column(name="mov_language", nullable=false)
	private String movLanguage; 

	@Column(name="mov_runtime", nullable=false)
	private int movRuntime;

	@Column(name="mov_director", nullable=false)
	private String movDirector;

	@Column(name="mov_cast", nullable=false)
	private String movCast;

	@Column(name="mov_rating", nullable=false)
	private double movRating;

	@Column(name="mov_genre_id", nullable=false)
	private int movGenreId;

}
