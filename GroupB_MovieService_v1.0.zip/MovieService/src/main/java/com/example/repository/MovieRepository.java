package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entity.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {

	List<Movie> findByMovGenreId (int genreId);
	
    @Query("SELECT m FROM Movie m WHERE " +
            "CONCAT('', m.mov_id) LIKE CONCAT('%', :keyword, '%') OR " +
    		"LOWER(m.movTitle) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(m.movDescription) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CONCAT('', m.movRelYear) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(m.movLanguage) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CONCAT('', m.movRuntime) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(m.movDirector) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(m.movCast) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(m.movRating AS string) LIKE CONCAT('%', :keyword, '%')")
	List<Movie> searchMoviesByKeyword(@Param("keyword") String keyword);
    

    @Query("SELECT m FROM Movie m WHERE " +
            "CONCAT('', m.mov_id) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(m.movTitle) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(m.movDescription) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CONCAT('', m.movRelYear) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(m.movLanguage) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CONCAT('', m.movRuntime) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(m.movDirector) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(m.movCast) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(m.movRating AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "m.movGenreId IN :genreIds")
    List<Movie> searchAllColumns(@Param("keyword") String keyword, @Param("genreIds") List<Integer> genreIds);
}
