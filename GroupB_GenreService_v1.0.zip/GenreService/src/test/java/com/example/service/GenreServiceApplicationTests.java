package com.example.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
