package com.example.service.controllers;

import com.example.service.entity.Genre;
import com.example.service.responses.GenreResponse;
import com.example.service.services.GenreService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/genres/")
public class GenreController {
    @Autowired
    private RestTemplate restobj;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private GenreService serv;

    @GetMapping("/id")
    public ResponseEntity<GenreResponse> GetById(@RequestParam int genre_id) {
        Genre emp = serv.getMovieGenreById(genre_id);
        GenreResponse resp = modelMapper.map(emp, GenreResponse.class);

        return ResponseEntity.status(HttpStatus.OK).body(resp);
    }

    @GetMapping("/list")
    public ResponseEntity<List<Genre>> GetAll() {
        List<Genre> genres = serv.getAllGenres();
        return ResponseEntity.status(HttpStatus.OK).body(genres);
    }

    @PostMapping("/add")
    public ResponseEntity<GenreResponse> AddNew(@RequestBody Genre gen) {
        Genre genre = serv.addNewGenre(gen);
        GenreResponse resp = modelMapper.map(genre, GenreResponse.class);

        return ResponseEntity.status(HttpStatus.OK).body(resp);
    }

    @PutMapping("/update")
    public ResponseEntity<GenreResponse> Update(@RequestBody Genre gen) {
        Genre genre = serv.updateGenre(gen);
        GenreResponse resp = modelMapper.map(genre, GenreResponse.class);

        return ResponseEntity.status(HttpStatus.OK).body(resp);
    }
    
	//get a list of  genre ids with genre names matching the keyword
    @GetMapping("/searchByKeyword")
    public ResponseEntity<List<Integer>> searchGenrebyName(@RequestParam(name = "keyword") String keyword) {
        // Check if a keyword is provided.
        if (keyword != null && !keyword.isEmpty()) {
			List<Integer> genreIDs=serv.getGenreIdsByKeyword(keyword);
			return ResponseEntity.status(HttpStatus.OK).body(genreIDs);	            
        } else {
            // If no keyword is provided, return an empty list.
			List<Integer> genreIDs=Collections.emptyList();
			return ResponseEntity.status(HttpStatus.OK).body(genreIDs);
        }
    }
}
