package com.example.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GenreResponse {
	   private int genre_id;
	   private String genre_name;
}
